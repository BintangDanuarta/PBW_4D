document.write("<h1>Biodata Bintang</h1>")
const biodata = ["Bintang Danuarta", "3D Informatika", "2210631170014"];

document.write("<ul>");
for (let i = 0; i < biodata.length; i++) {
  document.write(`<li>${biodata[i]}</li>`);
}
document.write("</ul>");