<html>
    <head>
        <title>Bintang Danuarta</title>
    </head>
    <body>
        <table>
            <tr>
                <th>Nama:</th>
                <td>Bintang Danuarta</td>
            </tr>
            <tr>
                <th>Kelas:</th>
                <td>4D Informatika</td>
            </tr>
            <tr>
                <th>NPM:</th>
                <td>2210631170014</td>
            </tr>
        </table>  
        <h1>Aplikasi Penghitung BMI</h1>
        <form method="POST" action="">
            Berat Badan (kg) :
            <input type="number" name="berat"><br>
            <br>
            Tinggi Badan (cm):
            <input type="number" name="tinggi"><br>
            <br><input type="submit" name="hitung" value="Hitung BMI">
        </form>
      <?php 
        if(isset($_POST['hitung'])){
            echo "<h2>Hasil Perhitungan</h2>";
            echo "Berat Badan : ".$_POST['berat']." kg"."<br>";
            echo "Tinggi Badan: ".$_POST['tinggi']." cm"."<br>";
            $tinggi = $_POST['tinggi']/100; 
            $tinggi_rumus = $tinggi*$tinggi;
            $hasil_tinggi = number_format($tinggi_rumus, 2, '.', '');
            $hasil = $_POST['berat']/$hasil_tinggi;
            $hasil_ahir = number_format($hasil,2, '.', '');
            echo "BMI : ". $hasil_ahir."<br>";
            echo "<b>";
            if($hasil_ahir < 18.5){
                echo "Kategori BMI: Kurus";
            }else if(($hasil_ahir >= 18.5) && ($hasil_ahir <= 25)){
                echo "Kategori BMI: Normal";
            }else if(($hasil_ahir > 24.9) && ($hasil_ahir <=30)){
                echo "Kategori BMI: Gemuk";
            }else{
                echo "Kategori BMI: Obesitas";
            }
            echo "</b>";
        }
        ?>
    </body>
</html>