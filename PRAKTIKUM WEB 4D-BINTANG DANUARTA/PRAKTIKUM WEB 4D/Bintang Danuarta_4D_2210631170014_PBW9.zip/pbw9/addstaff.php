<?php
    include_once("./connect.php");

    if(isset($_POST["kirim"])) {
        $nama = $_POST["nama"];
        $telp = $_POST["telp"];
        $email = $_POST["email"];

        $query = mysqli_query($db, "INSERT INTO staff VALUES (
            NULL, '$nama', '$telp', '$email'
        )");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku</title>
</head>
<body>
    <h1>Menambahkan Staff</h1>

    <form action="" method="POST">
        <label for="nama">nama staff</label>
        <input type="text" id="nama" name="nama">
        <br>
        <br>
        <label for="telp">no telp</label>
        <input type="text" id="telp" name="telp">
        <br>
        <br>
        <label for="email">email</label>
        <input type="text" id="email" name="email">
        <br>
        <button type="submit" name="kirim">kirim</button>
    </form>

    <a href="./index.php">Back to homepage</a>
</body>
</html>