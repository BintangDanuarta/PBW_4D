<?php
    include_once("./connect.php");

    $query = mysqli_query($db, "SELECT * FROM staff");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Staff</title>
</head>
<body>
    <h1>Daftar Staff</h1>
    <table border="1">
        <tr>
            <td>ID</td>
            <td>ISBN</td>
            <td>Unit</td>
            <td>Email</td>
        </tr>

        <?php foreach ($query as $buku) { ?>
            <tr>
                <td><?php echo $buku["id"] ?></td>
                <td><?php echo $buku["nama"] ?></td>
                <td><?php echo $buku["telp"] ?></td>
                <td><?php echo $buku["email"] ?></td>
            </tr>
        
        <?php } ?>

        <a href="./addbook.php">Menambahkan Buku</a>
        <a href="./index.php">Back to homepage</a>
</body>
</html>