<?php

    //Menyambukan PHP ke MySQL
    $db = mysqli_connect("localhost", "root", "", "bintang_library") or die("Koneksi Gagal");