<?php
    include_once("./connect.php");

    $id = $_GET["id"]

    $query_get_data = mysqli_query($db, "SELECT * FROM buku WHERE id=$id");
    $buku = mysqli_fetch_assoc($query_get_data);

    if(isset($_POST["kirim"])) {
        $judul = $_POST["judul"];
        $isbn = $_POST["isbn"];
        $unit = $_POST["unit"];

        $query = mysqli_query($db, "INSERT INTO buku VALUES (
            NULL, '$judul', '$isbn', $unit
        )");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku</title>
</head>
<body>
    <h1>Mengedit data Buku</h1>

    <form action="" method="POST">
        <label for="judul">Judul Buku</label>
        <input value="<?php echo $buku['judul'] ?>" type="text" id="judul" name="judul">
        <br>
        <br>
        <label for="isbn">ISBN</label>
        <input value="<?php echo $buku['isbn'] ?>" type="text" id="ISBN" name="isbn">
        <br>
        <br>
        <label for="unit">Unit</label>
        <input value="<?php echo $buku['unit'] ?>" type="text" id="unit" name="unit">
        <br>
        <button type="submit" name="kirim">kirim</button>
    </form>

    <a href="./index.php">Back to homepage</a>
</body>
</html>